## To contribute simply open a pull request and edit the README.md. You can find a list of contibution ideas [here](https://github.com/mezotv/discord-badges/issues)
